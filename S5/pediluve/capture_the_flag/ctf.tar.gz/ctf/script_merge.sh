#!/bin/sh

flag=$(cat file.txt | base64 | head -c 20)

echo $flag
