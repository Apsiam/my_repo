#include <stdio.h>

int main(void)
{
    puts("Hello World!");
    return 0;
}
